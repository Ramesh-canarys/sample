[[ condition: enterprise-only ]]

# Improvements to JavaScript analysis

## Changes to code extraction

* `import.meta` expressions no longer result in a syntax error in JavaScript files.
