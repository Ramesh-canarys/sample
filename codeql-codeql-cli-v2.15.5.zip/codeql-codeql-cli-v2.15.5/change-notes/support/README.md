# Files moved to ``docs`` directory

Now that all of the CodeQL documentation is in this repository,
notes on the languages, compilers, and frameworks supported have moved.
They're now stored as part of the Sphinx ``support`` project with the other documentation:
``docs/language/support``.
