lgtm,codescanning
* Improvements have been made to the `cpp/toctou-race-condition` query, both to find more correct results and fewer false positive results.
