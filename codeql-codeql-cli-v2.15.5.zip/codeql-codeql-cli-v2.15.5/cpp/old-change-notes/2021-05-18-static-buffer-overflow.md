lgtm
* The "Static buffer overflow" query (cpp/static-buffer-overflow) has been improved to produce fewer false positives.
