codescanning
* Added cpp/diagnostics/failed-extractions. This query gives information about which extractions did not run to completion.
