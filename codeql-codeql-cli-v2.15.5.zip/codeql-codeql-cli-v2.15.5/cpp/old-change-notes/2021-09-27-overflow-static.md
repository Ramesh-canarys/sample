lgtm,codescanning
* Increase precision to high for the "Static buffer overflow" query
  (`cpp/static-buffer-overflow`). This means the query is run and displayed by default on Code Scanning and LGTM.
