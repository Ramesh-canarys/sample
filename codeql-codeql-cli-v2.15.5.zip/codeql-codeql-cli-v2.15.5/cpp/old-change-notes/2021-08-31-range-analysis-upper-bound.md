lgtm,codescanning
* The `SimpleRangeAnalysis` library includes information from the
  immediate guard for determining the upper bound of a stack
  variable for improved accuracy.
