void f() {
	static int i = 0; //i is unused
	...
	return;
}
