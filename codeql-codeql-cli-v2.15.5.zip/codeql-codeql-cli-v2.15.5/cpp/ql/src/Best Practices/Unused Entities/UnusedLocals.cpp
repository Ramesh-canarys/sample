{
	int x = 0; //x is unused
	int y = 0;
	cout << y;
}
