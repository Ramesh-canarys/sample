if(strcpy(szbuf1, "Manager") == 0) // most likely strcmp was intended instead of strcpy
{
	// ...
}
