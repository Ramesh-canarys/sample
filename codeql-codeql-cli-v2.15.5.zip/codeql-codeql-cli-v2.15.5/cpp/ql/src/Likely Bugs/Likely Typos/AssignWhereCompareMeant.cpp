if(p = NULL) { //most likely == was intended. Otherwise it evaluates to the value
               //of the rhs of the assignment (which is NULL)
 ...
}
