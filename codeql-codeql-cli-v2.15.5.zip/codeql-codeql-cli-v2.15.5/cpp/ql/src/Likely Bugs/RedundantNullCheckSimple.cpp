int f(MyList *list) {
	list->append(1);

	// ...

	if (list != NULL)
	{
		list->append(2);
	}
}
