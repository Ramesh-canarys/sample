void h() {
	int a, b, c;

	a < b != c; //parenthesize to explicitly define order of operators
	(a < b) < c; //correct: parenthesized to specify order
}
