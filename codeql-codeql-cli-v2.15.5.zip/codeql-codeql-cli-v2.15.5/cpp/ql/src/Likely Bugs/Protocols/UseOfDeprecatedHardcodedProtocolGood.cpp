
void useProtocol_good()
{
	boost::asio::ssl::context cxt_tlsv13(boost::asio::ssl::context::tlsv13);

	// ...
}
