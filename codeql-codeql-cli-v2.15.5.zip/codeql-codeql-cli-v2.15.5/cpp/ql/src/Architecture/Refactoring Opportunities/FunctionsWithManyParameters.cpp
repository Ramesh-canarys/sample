// this example has 15 parameters.
void fillRect(int x, int y, int w, int h,
              int r1, int g1, int b1, int a1,
              int r2, int g2, int b2, int a2,
              gradient_type grad, unsigned int flags, bool border)
{
    // ...
}
