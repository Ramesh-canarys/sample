{
	int i;

	...
	int g = COEFF * i; //i is used before it is initialized
}
