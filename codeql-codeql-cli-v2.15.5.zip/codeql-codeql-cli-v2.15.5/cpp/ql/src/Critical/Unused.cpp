{
	int foo = 1;
	... //foo is unused
}
