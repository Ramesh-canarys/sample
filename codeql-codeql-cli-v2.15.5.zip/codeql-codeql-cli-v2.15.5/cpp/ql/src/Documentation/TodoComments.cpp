int isOdd(int n) {
	//TODO: Works only for positive n. Need to check if negative n is valid input
	return (n % 2) == 1;
}